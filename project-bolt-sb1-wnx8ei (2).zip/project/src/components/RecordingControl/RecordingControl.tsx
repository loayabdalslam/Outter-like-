import React from 'react';
import { Mic, MicOff } from 'lucide-react';

interface RecordingControlProps {
  isRecording: boolean;
  onToggle: () => void;
}

export function RecordingControl({ isRecording, onToggle }: RecordingControlProps) {
  return (
    <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50">
      <button
        onClick={onToggle}
        className={`p-4 rounded-full shadow-lg transition-colors ${
          isRecording ? 'bg-red-500 hover:bg-red-600' : 'bg-blue-500 hover:bg-blue-600'
        }`}
      >
        {isRecording ? (
          <MicOff className="w-6 h-6 text-white" />
        ) : (
          <Mic className="w-6 h-6 text-white" />
        )}
      </button>
    </div>
  );
}