import React from 'react';
import { Header } from './Header/Header';
import { SideNav } from './Navigation/SideNav';
import { AIChatSidebar } from './Sidebar/AIChatSidebar';
import { TranscriptionList } from './Transcription/TranscriptionList';
import { TranscriptionHeader } from './Transcription/TranscriptionHeader';
import { TranscriptionMessage } from '../types';

interface TranscriptionViewProps {
  messages: TranscriptionMessage[];
  isRecording: boolean;
}

export function TranscriptionView({ messages, isRecording }: TranscriptionViewProps) {
  return (
    <div className="flex flex-col h-screen">
      <Header />
      <main className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto px-8 py-6">
          <TranscriptionHeader isRecording={isRecording} />
          <TranscriptionList messages={messages} />
        </div>
      </main>
      <SideNav />
      <AIChatSidebar />
    </div>
  );
}