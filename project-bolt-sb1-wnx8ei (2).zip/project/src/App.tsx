import React, { useState, useEffect } from 'react';
import { useAudioCapture } from './hooks/useAudioCapture';
import { TranscriptionView } from './components/TranscriptionView';
import { RecordingControl } from './components/RecordingControl/RecordingControl';
import { TranscriptionMessage } from './types';
import { GeminiService } from './services/GeminiService';

const geminiService = new GeminiService(import.meta.env.VITE_GEMINI_API_KEY);

function App() {
  const { isRecording, error, startRecording, stopRecording } = useAudioCapture();
  const [messages, setMessages] = useState<TranscriptionMessage[]>([]);

  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setMessages(prev => [...prev, {
          text: 'This is a simulated transcription. Replace with actual transcribed text.',
          timestamp: new Date(),
        }]);
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [isRecording]);

  const handleToggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  return (
    <div className="h-screen bg-gray-50">
      <RecordingControl 
        isRecording={isRecording}
        onToggle={handleToggleRecording}
      />

      {error && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            {error.message}
          </div>
        </div>
      )}

      <TranscriptionView 
        messages={messages}
        isRecording={isRecording}
      />
    </div>
  );
}

export default App;