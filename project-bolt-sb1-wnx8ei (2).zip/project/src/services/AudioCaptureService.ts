import { CHUNK_SIZE, SEND_INTERVAL, formatAudioData } from '../utils/audioUtils';

export class AudioCaptureService {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private chunks: Float32Array[] = [];
  private chunkCount = 0;

  async initialize(): Promise<void> {
    try {
      // Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
        video: false,
      });

      this.mediaStream = stream;
      
      // Initialize audio context
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = this.audioContext.createMediaStreamSource(stream);
      
      // Create processor
      this.processor = this.audioContext.createScriptProcessor(CHUNK_SIZE, 1, 1);
      
      this.processor.onaudioprocess = this.handleAudioProcess.bind(this);
      
      // Connect the nodes
      source.connect(this.processor);
      this.processor.connect(this.audioContext.destination);
      
    } catch (error) {
      this.handleError(error);
    }
  }

  private async handleAudioProcess(event: AudioProcessingEvent) {
    const inputData = event.inputBuffer.getChannelData(0);
    this.chunks.push(new Float32Array(inputData));
    this.chunkCount++;

    if (this.chunkCount >= SEND_INTERVAL) {
      await this.sendAudioChunks();
      this.chunkCount = 0;
      this.chunks = [];
    }
  }

  private async sendAudioChunks() {
    try {
      // Combine all chunks
      const combinedLength = this.chunks.reduce((acc, chunk) => acc + chunk.length, 0);
      const combinedChunks = new Float32Array(combinedLength);
      
      let offset = 0;
      for (const chunk of this.chunks) {
        combinedChunks.set(chunk, offset);
        offset += chunk.length;
      }

      const audioBlob = formatAudioData(combinedChunks);
      
      const response = await fetch('http://localhost:5000/transcribe', {
        method: 'POST',
        body: audioBlob,
        headers: {
          'Content-Type': 'audio/wav',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
    } catch (error) {
      this.handleError(error);
    }
  }

  private handleError(error: unknown) {
    console.error('Audio capture error:', error);
    this.cleanup();
    throw error;
  }

  cleanup() {
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }

    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }

    this.chunks = [];
    this.chunkCount = 0;
  }
}